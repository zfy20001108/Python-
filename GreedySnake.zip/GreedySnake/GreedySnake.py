import random

import pygame

import sys

from pygame.locals import *

Snakespeed = 10

Window_Width = 800  # Width and height of the cells

Window_Height = 500

Cell_Size = 20

assert Window_Width % Cell_Size == 0, "Window width must be a multiple of cell size."

# Ensuring that only whole integer number of cells fit perfectly in the window.

assert Window_Height % Cell_Size == 0, "Window height must be a multiple of cell size."

Cell_W = int(Window_Width / Cell_Size)  # Cell Width

Cell_H = int(Window_Height / Cell_Size)  # Cellc Height

White = (255, 255, 255)

Black = (0, 0, 0)

Red = (255, 0, 0)  # Defining element colors for the program.

Green = (0, 255, 0)

DARKGreen = (0, 155, 0)

DARKGRAY = (40, 40, 40)

YELLOW = (255, 255, 0)

Red_DARK = (150, 0, 0)

BLUE = (0, 0, 255)

BLUE_DARK = (0, 0, 150)

BGCOLOR = Black  # Background color

UP = 'up'

DOWN = 'down'  # Defining keyboard keys.

LEFT = 'left'

RIGHT = 'right'

HEAD = 0  # Syntactic sugar: index of the snake's head

File0 = open("data.txt", "r")

HighestScore = int(File0.read())
HighestScore0 = HighestScore
File0.close()
Back=False#the symbol of back

def main():
    global SnakespeedCLOCK, DISPLAYSURF, BASICFONT, Snakespeed, SnakeColor, SnakeBodyColor,Back

    pygame.init()

    SnakespeedCLOCK = pygame.time.Clock()

    DISPLAYSURF = pygame.display.set_mode((Window_Width, Window_Height))

    SnakeColor = DARKGreen

    SnakeBodyColor = Green

    BASICFONT = pygame.font.SysFont('arial', 18)

    pygame.display.set_caption('GreedySnake')

    showStartScreen()

    a = 4

    while a == 4:

        a = selectmode()

        if a == 1:
            while True:
                Snakespeed = 10
                runGame1()
                if (Back == True):
                    break
                showGameOverScreen()
            if (Back == True):
                Back = False
                a=4
        elif a == 2:
            while True:
                Snakespeed = 5
                runGame2()
                if (Back == True):
                    break
                showGameOverScreen()
            if (Back == True):
                Back = False
                a=4
        elif a == 3:
            while True:
                Snakespeed = 10
                runGame3()
                if (Back == True):
                    break
                showGameOverScreen()
            if (Back == True):
                Back = False
                a=4
        elif a == 4:
            b = setcolor()
            if b == 1:
                SnakeColor = setSnakeColor()
            elif b == 2:
                SnakeBodyColor = setSnakeColor()
            elif b == 3:
                pass



def runGame1():
    # Set a random start point.

    global Snakespeed,Back

    startx = random.randint(5, Cell_W - 6)

    starty = random.randint(5, Cell_H - 6)

    wormCoords = [{'x': startx, 'y': starty},

                  {'x': startx - 1, 'y': starty},

                  {'x': startx - 2, 'y': starty}]

    direction = RIGHT

    # Start the apple in a random place.

    apple = getRandomLocation(wormCoords)

    while True:  # main game loop

        for event in pygame.event.get():  # event handling loop

            if event.type == QUIT:

                terminate()

            elif event.type == KEYDOWN:

                if (event.key == K_LEFT or event.key == K_a) and direction != RIGHT:

                    direction = LEFT

                elif (event.key == K_RIGHT or event.key == K_d) and direction != LEFT:

                    direction = RIGHT

                elif (event.key == K_UP or event.key == K_w) and direction != DOWN:

                    direction = UP

                elif (event.key == K_DOWN or event.key == K_s) and direction != UP:

                    direction = DOWN

                elif event.key==K_BACKSPACE:
                    Back=True


                elif event.key == K_ESCAPE:

                    terminate()

        if (Back == True):
            break
        # check if the Snake has hit itself or the edge

        if wormCoords[HEAD]['x'] == -1 or wormCoords[HEAD]['x'] == Cell_W or wormCoords[HEAD]['y'] == -1 or \
                wormCoords[HEAD]['y'] == Cell_H:
            return  # game over

        for wormBody in wormCoords[1:]:

            if wormBody['x'] == wormCoords[HEAD]['x'] and wormBody['y'] == wormCoords[HEAD]['y']:
                return  # game over

        # check if Snake has eaten an apply

        if wormCoords[HEAD]['x'] == apple['x'] and wormCoords[HEAD]['y'] == apple['y']:

            # don't remove worm's tail segment

            apple = getRandomLocation(wormCoords)  # set a new apple somewhere

        else:

            del wormCoords[-1]  # remove worm's tail segment

        # move the worm by adding a segment in the direction it is moving

        if direction == UP:

            newHead = {'x': wormCoords[HEAD]['x'],

                       'y': wormCoords[HEAD]['y'] - 1}

        elif direction == DOWN:

            newHead = {'x': wormCoords[HEAD]['x'],

                       'y': wormCoords[HEAD]['y'] + 1}

        elif direction == LEFT:

            newHead = {'x': wormCoords[HEAD][

                                'x'] - 1, 'y': wormCoords[HEAD]['y']}

        elif direction == RIGHT:

            newHead = {'x': wormCoords[HEAD][

                                'x'] + 1, 'y': wormCoords[HEAD]['y']}

        wormCoords.insert(0, newHead)

        DISPLAYSURF.fill(BGCOLOR)

        drawWorm(wormCoords)

        drawApple(apple)

        drawScore(len(wormCoords) - 3)

        pygame.display.update()

        SnakespeedCLOCK.tick(Snakespeed)


def runGame2():
    # Set a random start point.
    global Snakespeed,Back
    Orix = random.randint(5, Cell_W - 6)

    Oriy = random.randint(5, Cell_H - 6)

    wormCoords = [{'x': Orix, 'y': Oriy},

                  {'x': Orix - 1, 'y': Oriy},

                  {'x': Orix - 2, 'y': Oriy}]

    direction = RIGHT

    # Start the apple in a random place.

    apple = getRandomLocation(wormCoords)

    while True:  # main game loop

        for event in pygame.event.get():  # event handling loop

            if event.type == QUIT:

                terminate()

            elif event.type == KEYDOWN:

                if (event.key in (K_LEFT, K_a)) and direction != RIGHT:

                    direction = LEFT

                elif (event.key in (K_RIGHT, K_d)) and direction != LEFT:

                    direction = RIGHT

                elif (event.key in (K_UP, K_w)) and direction != DOWN:

                    direction = UP

                elif (event.key in (K_DOWN, K_s)) and direction != UP:

                    direction = DOWN

                elif event.key==K_BACKSPACE:
                    Back=True

                elif event.key == K_ESCAPE:

                    terminate()
        if (Back == True):
            break
        # check if the Snake has hit itself or the edge

        if wormCoords[HEAD]['x'] == -1 or wormCoords[HEAD]['x'] == Cell_W or wormCoords[HEAD]['y'] == -1 or \
                wormCoords[HEAD]['y'] == Cell_H:
            return  # game over

        for wormBody in wormCoords[1:]:

            if wormBody['x'] == wormCoords[HEAD]['x'] and wormBody['y'] == wormCoords[HEAD]['y']:
                return  # game over

        # check if Snake has eaten an apply

        if wormCoords[HEAD]['x'] == apple['x'] and wormCoords[HEAD]['y'] == apple['y']:

            # don't remove worm's tail segment

            apple = getRandomLocation(wormCoords)  # set a new apple somewhere

        else:

            del wormCoords[-1]  # remove worm's tail segment

        # move the worm by adding a segment in the direction it is moving

        if direction == UP:

            newHead = {'x': wormCoords[HEAD]['x'],

                       'y': wormCoords[HEAD]['y'] - 1}

        elif direction == DOWN:

            newHead = {'x': wormCoords[HEAD]['x'],

                       'y': wormCoords[HEAD]['y'] + 1}

        elif direction == LEFT:

            newHead = {'x': wormCoords[HEAD]['x'] - 1, 'y': wormCoords[HEAD]['y']}

        elif direction == RIGHT:

            newHead = {'x': wormCoords[HEAD]['x'] + 1, 'y': wormCoords[HEAD]['y']}

        wormCoords.insert(0, newHead)

        DISPLAYSURF.fill(BGCOLOR)

        drawWorm(wormCoords)

        drawApple(apple)

        drawGrid()

        drawScore(len(wormCoords) - 3)

        pygame.display.update()

        SnakespeedCLOCK.tick(Snakespeed)

        if (len(wormCoords) == 6 and Snakespeed != 10):
            Snakespeed = Snakespeed + 5
        elif (len(wormCoords) == 9 and Snakespeed != 15):
            Snakespeed = Snakespeed + 5
        elif (len(wormCoords) == 6 and Snakespeed != 10):
            Snakespeed = Snakespeed + 5
        elif (len(wormCoords) == 18 and Snakespeed != 20):
            Snakespeed = Snakespeed + 5


def runGame3():
    # Set a random start point.

    global Snakespeed, eatapplenumber,Back

    startx = random.randint(5, Cell_W - 6)

    starty = random.randint(5, Cell_H - 6)

    wormCoords = [{'x': startx, 'y': starty},

                  {'x': startx - 1, 'y': starty},

                  {'x': startx - 2, 'y': starty}]

    direction = RIGHT

    eatapplenumber = 0

    up = K_UP
    down = K_DOWN
    left = K_LEFT
    right = K_RIGHT
    w = K_w
    s = K_s
    a = K_a
    d = K_d

    # Start the apple in a random place.

    apple = getRandomLocation(wormCoords)

    while True:  # main game loop

        for event in pygame.event.get():  # event handling loop

            if event.type == QUIT:

                terminate()

            elif event.type == KEYDOWN:

                if (event.key == left or event.key == a) and direction != RIGHT:

                    direction = LEFT

                elif (event.key == right or event.key == d) and direction != LEFT:

                    direction = RIGHT

                elif (event.key == up or event.key == w) and direction != DOWN:

                    direction = UP

                elif (event.key == down or event.key == s) and direction != UP:

                    direction = DOWN

                elif event.key==K_BACKSPACE:
                    Back=True

                elif event.key == K_ESCAPE:

                    terminate()
        if Back==True:
            break
        # check if the Snake has hit itself or the edge

        if wormCoords[HEAD]['x'] == -1 or wormCoords[HEAD]['x'] == Cell_W or wormCoords[HEAD]['y'] == -1 or \
                wormCoords[HEAD]['y'] == Cell_H:
            return  # game over

        for wormBody in wormCoords[1:]:

            if wormBody['x'] == wormCoords[HEAD]['x'] and wormBody['y'] == wormCoords[HEAD]['y']:
                return  # game over

        # check if Snake has eaten an apply

        if wormCoords[HEAD]['x'] == apple['x'] and wormCoords[HEAD]['y'] == apple['y']:

            # don't remove worm's tail segment
            if eatapplenumber % 4 == 0 and eatapplenumber != 0:
                up, down = down, up
                left, right = right, left
                w, s = s, w
                a, d = d, a

            elif eatapplenumber % 5 == 0 and eatapplenumber != 0:
                Snakespeed += 5
            apple = getRandomLocation(wormCoords)  # set a new apple somewhere
            eatapplenumber = eatapplenumber + 1

        else:

            del wormCoords[-1]  # remove worm's tail segment

        # move the worm by adding a segment in the direction it is moving

        if direction == UP:

            newHead = {'x': wormCoords[HEAD]['x'],

                       'y': wormCoords[HEAD]['y'] - 1}

        elif direction == DOWN:

            newHead = {'x': wormCoords[HEAD]['x'],

                       'y': wormCoords[HEAD]['y'] + 1}

        elif direction == LEFT:

            newHead = {'x': wormCoords[HEAD][

                                'x'] - 1, 'y': wormCoords[HEAD]['y']}

        elif direction == RIGHT:

            newHead = {'x': wormCoords[HEAD][

                                'x'] + 1, 'y': wormCoords[HEAD]['y']}

        wormCoords.insert(0, newHead)

        DISPLAYSURF.fill(BGCOLOR)

        drawWorm(wormCoords)

        if eatapplenumber % 4 == 0 and eatapplenumber != 0:
            drawTool2(apple)

        elif eatapplenumber % 5 == 0 and eatapplenumber != 0:
            drawTool1(apple)
        else:
            drawApple(apple)

        drawScore(len(wormCoords) - 3)

        pygame.display.update()

        SnakespeedCLOCK.tick(Snakespeed)


def drawPressKeyMsg():
    pressKeySurf = BASICFONT.render('Press a key to play.', True, White)

    pressKeyRect = pressKeySurf.get_rect()

    pressKeyRect.topleft = (Window_Width - 200, Window_Height - 30)

    DISPLAYSURF.blit(pressKeySurf, pressKeyRect)


def checkForKeyPress():
    if len(pygame.event.get(QUIT)) > 0:
        terminate()

    keyUpEvents = pygame.event.get(KEYUP)

    if len(keyUpEvents) == 0:
        return None

    if keyUpEvents[0].key == K_ESCAPE:
        terminate()

    return keyUpEvents[0].key


def showStartScreen():
    titleFont = pygame.font.SysFont('arial', 100)

    titleSurf1 = titleFont.render('Snake!', True, White, DARKGreen)

    degrees1 = 0

    degrees2 = 0

    while True:

        DISPLAYSURF.fill(BGCOLOR)

        rotatedSurf1 = pygame.transform.rotate(titleSurf1, degrees1)

        rotatedRect1 = rotatedSurf1.get_rect()

        rotatedRect1.center = (Window_Width / 2, Window_Height / 2)

        DISPLAYSURF.blit(rotatedSurf1, rotatedRect1)

        drawPressKeyMsg()

        if checkForKeyPress():
            pygame.event.get()  # clear event queue

            return

        pygame.display.update()

        SnakespeedCLOCK.tick(10)

        degrees1 += 3  # rotate by 3 degrees each frame

        degrees2 += 7  # rotate by 7 degrees each frame


def selectmode():
    titleFont = pygame.font.SysFont('arial', 50)
    titleSurf = titleFont.render('Snake', True, White)
    titleSurf2 = titleFont.render('World', True, White)
    titleRect = titleSurf.get_rect()
    titleRect2 = titleSurf2.get_rect()
    titleRect.midtop = (400, 10)
    titleRect2.midtop = (400, titleRect.height + 35)
    modeFont = pygame.font.SysFont('arial', 30)
    modeSurf1 = modeFont.render('Common mode', True, White)
    modeSurf2 = modeFont.render('Speedup mode', True, White)
    modeSurf3 = modeFont.render('Tool mode', True, White)
    setupSurf = modeFont.render('setup', True, White)
    arrowSurf = modeFont.render('->', True, White)
    exitSurf = modeFont.render('exit', True, White)
    modeRect1 = modeSurf1.get_rect()
    modeRect2 = modeSurf2.get_rect()
    modeRect3 = modeSurf3.get_rect()
    setupRect = setupSurf.get_rect()
    arrowRect = arrowSurf.get_rect()
    exitRect = exitSurf.get_rect()
    modeRect1.midtop = (400, titleRect.height + 200)
    modeRect2.midtop = (400, titleRect.height + 250)
    modeRect3.midtop = (400, titleRect.height + 300)
    setupRect.midtop = (400, titleRect.height + 350)
    exitRect.midtop = (400, titleRect.height + 400)
    arrowposition = titleRect.height + 200
    arrowRect.midtop = (250, arrowposition)
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key in (K_UP, K_w):
                    arrowposition -= 50
                elif event.key in (K_DOWN, K_s):
                    arrowposition += 50
                elif event.key == K_SPACE:
                    if arrowposition == titleRect.height + 200:
                        return 1
                    elif arrowposition == titleRect.height + 250:
                        return 2
                    elif arrowposition == titleRect.height + 300:
                        return 3
                    elif arrowposition == titleRect.height + 350:
                        return 4
                    elif arrowposition == titleRect.height + 400:
                        terminate()
            if arrowposition > titleRect.height + 400:
                arrowposition = titleRect.height + 200
            elif arrowposition < titleRect.height + 200:
                arrowposition = titleRect.height + 400
            arrowRect.midtop = (250, arrowposition)
            DISPLAYSURF.fill((0, 0, 0))
            DISPLAYSURF.blit(titleSurf, titleRect)
            DISPLAYSURF.blit(titleSurf2, titleRect2)
            DISPLAYSURF.blit(modeSurf1, modeRect1)
            DISPLAYSURF.blit(modeSurf2, modeRect2)
            DISPLAYSURF.blit(modeSurf3, modeRect3)
            DISPLAYSURF.blit(setupSurf, setupRect)
            DISPLAYSURF.blit(arrowSurf, arrowRect)
            DISPLAYSURF.blit(exitSurf, exitRect)
            pygame.display.update()


def setcolor():
    titleFont = pygame.font.SysFont('arial', 25)
    setcolor1Surf = titleFont.render("setSnakeedgeColor", True, White)
    setcolor2Surf = titleFont.render("setSnakeBodyColor", True, White)
    setcolor1Rect = setcolor1Surf.get_rect()
    setcolor2Rect = setcolor2Surf.get_rect()
    setcolor1Rect.midtop = (400, 200)
    setcolor2Rect.midtop = (400, 250)
    exitSurf = titleFont.render('exit', True, White)
    exitRect = exitSurf.get_rect()
    exitRect.midtop = (400, 300)
    arrowSurf = titleFont.render('->', True, White)
    arrowRect = arrowSurf.get_rect()
    arrowposition = 200
    arrowRect.midtop = (180, arrowposition)
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key in (K_UP, K_w):
                    arrowposition -= 50
                elif event.key in (K_DOWN, K_s):
                    arrowposition += 50
                elif event.key == K_SPACE:
                    if arrowposition == 200:
                        return 1
                    elif arrowposition == 250:
                        return 2
                    elif arrowposition == 300:
                        return 3
            if arrowposition > 300:
                arrowposition = 200
            elif arrowposition < 200:
                arrowposition = 300
            arrowRect.midtop = (250, arrowposition)
            DISPLAYSURF.fill((0, 0, 0))
            DISPLAYSURF.blit(setcolor1Surf, setcolor1Rect)
            DISPLAYSURF.blit(setcolor2Surf, setcolor2Rect)
            DISPLAYSURF.blit(arrowSurf, arrowRect)
            DISPLAYSURF.blit(exitSurf, exitRect)
            pygame.display.update()


def setSnakeColor():
    def create_scales(height):
        red_scale_surface = pygame.surface.Surface((800, height))
        green_scale_surface = pygame.surface.Surface((800, height))
        blue_scale_surface = pygame.surface.Surface((800, height))
        for x in range(800):
            c = int((x / 800.) * 255.)
            red = (c, 0, 0)
            green = (0, c, 0)
            blue = (0, 0, c)
            line_rect = Rect(x, 0, 1, height)
            pygame.draw.rect(red_scale_surface, red, line_rect)
            pygame.draw.rect(green_scale_surface, green, line_rect)
            pygame.draw.rect(blue_scale_surface, blue, line_rect)
        return red_scale_surface, green_scale_surface, blue_scale_surface

    red_scale, green_scale, blue_scale = create_scales(80)

    color = [127, 127, 127]

    while True:

        for event in pygame.event.get():
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if event.key == K_SPACE:
                    return tuple(color)

        DISPLAYSURF.fill((0, 0, 0))

        DISPLAYSURF.blit(red_scale, (0, 00))
        DISPLAYSURF.blit(green_scale, (0, 80))
        DISPLAYSURF.blit(blue_scale, (0, 160))

        x, y = pygame.mouse.get_pos()

        if pygame.mouse.get_pressed()[0]:
            for component in range(3):
                if y > component * 80 and y < (component + 1) * 80:
                    color[component] = int((x / 799.) * 255.)
            pygame.display.set_caption("SnakeColor  - " + str(tuple(color)))

        for component in range(3):
            pos = (int((color[component] / 255.) * 799), component * 80 + 40)
            pygame.draw.circle(DISPLAYSURF, (255, 255, 255), pos, 20)

        pygame.draw.rect(DISPLAYSURF, tuple(color), (0, 240, 800, 500))

        pygame.display.update()


def terminate():
    pygame.quit()

    sys.exit()


def getRandomLocation(wormCoords):
    while True:
        applex = random.randint(0, Cell_W - 1)
        appley = random.randint(0, Cell_H - 1)
        if {'x': applex, 'y': appley} not in wormCoords:
            break
    return {'x': applex, 'y': appley}


def showGameOverScreen():
    gameOverFont = pygame.font.SysFont('arial', 100)
    hscoreSurf = BASICFONT.render('HScore: %s' % (HighestScore), True, White)
    gameSurf = gameOverFont.render('Game', True, White)

    overSurf = gameOverFont.render('Over', True, White)
    hscoreRect = hscoreSurf.get_rect()
    gameRect = gameSurf.get_rect()

    overRect = overSurf.get_rect()

    gameRect.midtop = (Window_Width / 2, 10)
    hscoreRect.topleft = (10, 10)
    overRect.midtop = (Window_Width / 2, gameRect.height + 10 + 25)

    DISPLAYSURF.blit(gameSurf, gameRect)
    DISPLAYSURF.blit(hscoreSurf, hscoreRect)
    DISPLAYSURF.blit(overSurf, overRect)

    if (HighestScore != HighestScore0):
        File1 = open("data.txt", "w")
        File1.write(str(HighestScore))
        File1.close()
    drawPressKeyMsg()

    pygame.display.update()

    pygame.time.wait(500)

    checkForKeyPress()  # clear out any key presses in the event queue

    while True:

        if checkForKeyPress():
            pygame.event.get()  # clear event queue

            return


def drawScore(length):
    global Snakespeed, HighestScore
    if (length <= 3):
        score = length * Snakespeed
    elif (3 < length <= 6):
        score = 15 + (length - 3) * Snakespeed
    else:
        score = 45 + (length - 6) * Snakespeed
    if (score > HighestScore):
        HighestScore = score
    scoreSurf = BASICFONT.render('Score: %s' % (score), True, White)
    hscoreSurf = BASICFONT.render('HScore: %s' % (HighestScore), True, White)
    scoreRect = scoreSurf.get_rect()
    hscoreRect = hscoreSurf.get_rect()
    scoreRect.topleft = (Window_Width - 120, 10)
    hscoreRect.topleft = (10, 10)
    DISPLAYSURF.blit(scoreSurf, scoreRect)
    DISPLAYSURF.blit(hscoreSurf, hscoreRect)


def drawWorm(wormCoords):
    for coord in wormCoords:
        x = coord['x'] * Cell_Size

        y = coord['y'] * Cell_Size

        wormSegmentRect = pygame.Rect(x, y, Cell_Size, Cell_Size)

        pygame.draw.rect(DISPLAYSURF, SnakeColor, wormSegmentRect)

        wormInnerSegmentRect = pygame.Rect(

            x + 4, y + 4, Cell_Size - 8, Cell_Size - 8)

        pygame.draw.rect(DISPLAYSURF, SnakeBodyColor, wormInnerSegmentRect)


def drawApple(coord):
    x = coord['x'] * Cell_Size

    y = coord['y'] * Cell_Size

    appleRect = pygame.Rect(x, y, Cell_Size, Cell_Size)

    pygame.draw.rect(DISPLAYSURF, Red, appleRect)


def drawTool1(coord):
    x = coord['x'] * Cell_Size

    y = coord['y'] * Cell_Size

    appleRect = pygame.Rect(x, y, Cell_Size, Cell_Size)

    pygame.draw.rect(DISPLAYSURF, YELLOW, appleRect)


def drawTool2(coord):
    x = coord['x'] * Cell_Size

    y = coord['y'] * Cell_Size

    appleRect = pygame.Rect(x, y, Cell_Size, Cell_Size)

    pygame.draw.rect(DISPLAYSURF, (255, 0, 255), appleRect)


def layTool1(wormCoords):
    x = wormCoords[-1]['x'] * Cell_Size

    y = wormCoords[-1]['y'] * Cell_Size

    toolRect = pygame.Rect(x, y, Cell_Size, Cell_Size)

    pygame.draw.rect(DISPLAYSURF, BLUE, toolRect)

    return 1


def layTool2(wormCoords):
    x = wormCoords[-1]['x'] * Cell_Size

    y = wormCoords[-1]['y'] * Cell_Size

    toolRect = pygame.Rect(x, y, Cell_Size, Cell_Size)

    pygame.draw.rect(DISPLAYSURF, BLUE_DARK, toolRect)

    return 2


def drawGrid():
    for x in range(0, Window_Width, Cell_Size):  # draw vertical lines

        pygame.draw.line(DISPLAYSURF, DARKGRAY, (x, 0), (x, Window_Height))

    for y in range(0, Window_Height, Cell_Size):  # draw horizontal lines

        pygame.draw.line(DISPLAYSURF, DARKGRAY, (0, y), (Window_Width, y))


if __name__ == '__main__':

    try:

        main()

    except SystemExit:

        pass